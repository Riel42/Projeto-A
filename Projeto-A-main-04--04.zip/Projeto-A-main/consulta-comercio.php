<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta do amigo</title>
</head>
<body>
    <?php 
        include_once "factory/conexao.php";
        $nome = $_POST['buscar-nome'];
        $consulta = "select * from tbcomercial where nome = '$nome'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
    ?>

    <form>
        Nome: <?php echo $linha['nome']?><br> <!-- esse 'nome' é o da tabela -->
        Comércio: <?php echo $linha['comercio']?><br> 
        Telefone: <?php echo $linha['telefone']?><br> 
        WhatsApp: <?php echo $linha['whast']?><br>
    </form>
</body>
</html>