<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_menu.css">
    <title>Tela Menu</title>
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">
            <a href="#" style="font-size: 85pt; position: absolute; left: 0px">Bambolee: Menu</a>
        </header>
        <nav id="cxamigo">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="tela_cad_amigos.php"><img src="img/msn.png" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="tela_cad_amigos.php">INSERIR AMIGO</a></figcaption>
            </figure>
        </nav>
        <nav id="cxcomercio">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="tela_cad_comercial.php"><img src="https://preview.redd.it/learning-inkscape-to-make-frutiger-aero-art-started-with-a-v0-wfzi11uh6yhb1.png?width=1080&crop=smart&auto=webp&s=7a3d06afed899ed358c64a347ff5b0c2705e0d5e" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="tela_cad_comercial.php">INSERIR COMÉRCIO</a></figcaption>
            </figure>
        </nav>
        <nav id="cxusuario">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="cadastro_user.php"><img src="https://i.pinimg.com/originals/b6/89/81/b6898148bfa9df9e67330fca31571f9b.png" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="cadastro_user.php">INSERIR USUÁRIO</a></figcaption>
            </figure>
        </nav>
        <nav id="cxconsultaamigo">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="tela_cad_amigos.php"><img src="img/msn.png" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="tela_cad_amigos.php">BUSCAR AMIGO</a></figcaption>
            </figure>
            <figure>
                <img src="img/magnifier.webp" alt="" width="30px" height="30px">
            </figure>
        </nav>
        <nav id="cxconsultacomercio">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="tela_cad_comercial.php"><img src="https://preview.redd.it/learning-inkscape-to-make-frutiger-aero-art-started-with-a-v0-wfzi11uh6yhb1.png?width=1080&crop=smart&auto=webp&s=7a3d06afed899ed358c64a347ff5b0c2705e0d5e" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="tela_cad_comercial.php">BUSCAR COMÉRCIO</a></figcaption>
            </figure>
            <figure>
                <img src="img/magnifier.webp" alt="" width="30px" height="30px">
            </figure>
        </nav>
        <nav id="cxconsultauser">
        <figure style="position: absolute; margin-top: 10px; margin-left: 20px;">
               <a href="cadastro_user.php"><img src="https://i.pinimg.com/originals/b6/89/81/b6898148bfa9df9e67330fca31571f9b.png" alt="" width="290px" height="290px"></a>
                <figcaption style="text-align: center"><a href="cadastro_user.php">BUSCAR USUÁRIO</a></figcaption>
            </figure>
            <figure>
                <img src="img/magnifier.webp" alt="" width="30px" height="30px">
            </figure>
        </nav>
    </section>
</body>
</html>