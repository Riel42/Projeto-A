<?php 
    if($_POST["nome"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $nome = $_POST["nome"];
        $comercio = $_POST["comercio"];
        $telefone = $_POST["telefone"];
        $whatsapp = $_POST["whatsapp"];

        $comando_sql = "insert into tbcomercial(nome, comercio, telefone, whast) 
        values('$nome', '$comercio', '$telefone', '$whatsapp')";

        $inserir = mysqli_query($conectar, $comando_sql); 
        //Primeiro conectará no BD e depois ele vai executar o comando 

        echo "Dados cadastrados com sucesso!";
    }
    else{
        echo "Dados não cadastrados!";
    }
?>