<?php
    $server_bd = "localhost";
    $user_bd = "root";
    $senha_bd = "senha";
    $nome_bd = "bdagenda2000";

    $conectar = mysqli_connect($server_bd, $user_bd, $senha_bd, $nome_bd);
?>