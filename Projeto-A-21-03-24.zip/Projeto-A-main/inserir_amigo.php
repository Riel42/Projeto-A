<?php 
    if($_POST["amigo"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $amigo = $_POST["amigo"];
        $email = $_POST["email"];
        $telefone = $_POST["telefone"];
        $whatsapp = $_POST["whatsapp"];
        $datanasc = $_POST["datanasc"];

        $comando_sql = "insert into tbamigos(amigo, email, telefone, whast, datanasc) 
        values('$amigo', '$email', '$telefone', '$whatsapp','$datanasc')";

        $inserir = mysqli_query($conectar, $comando_sql); 
        //Primeiro conectará no BD e depois ele vai executar o comando 

        echo "Dados cadastrados com sucesso!";
    }
    else{
        echo "Dados não cadastrados!";
    }
?>